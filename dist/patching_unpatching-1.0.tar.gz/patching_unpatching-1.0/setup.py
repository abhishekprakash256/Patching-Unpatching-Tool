# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['patching_unpatching']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.19.2,<1.20.0', 'torch==1.4.0']

setup_kwargs = {
    'name': 'patching-unpatching',
    'version': '1.0',
    'description': 'A tool to cut image to make patches and combine them to make image images',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.8.5',
}


setup(**setup_kwargs)
